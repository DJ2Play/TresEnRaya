package TresEnRaya;

public class IA1 extends IA0 {

    public IA1() {
        super();
    }
}
