package TresEnRaya;

public class Taulell {

    private int[][] caselles;

    public Taulell() {
        caselles = new int[3][3];

        for (int f = 0; f < caselles.length; f++) { //rellenar de "vacío" el tablero
            for (int c = 0; c < caselles.length; c++) {
                this.caselles[f][c] = -1;
            }
        }
    }

    public boolean comprovarGuanyador() { // comprobar si el movimiento dado es un mov. ganador
        return (comprovarGuanyadorFiles() || comprovarGuanyadorColumnes() || comprovaGuanyadorDiagonals());
    }

    public boolean comprovarEmpat() { // comprovar si el tablero está lleno (decide si hay empate)
        for (int f = 0; f < caselles.length; f++) { // recorrer toda la array para saber si esta toda llena!!! --> comprueba si esta vacío
            for (int c = 0; c < caselles.length; c++) {
                if (getCasella(f, c) == -1) { // si esta vacía (es decir == -1), devolver false
                    return false;
                }
            }
        }
        return true;
    }

    public boolean comprovarGuanyadorFiles() { //comprueba si en una fila tiene fichas iguales XXX o OOO
        for (int f = 0; f < 3; f++) {
            if (getCasella(f, 0) == getCasella(f, 1) && getCasella(f, 1) == getCasella(f, 2)) {
                if (getCasella(f, 0) != -1 && getCasella(f, 1) != -1 && getCasella(f, 2) != -1) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean comprovarGuanyadorColumnes() { // comprueba si en una columna tiene fichas iguales XXX o OOO
        for (int c = 0; c < 3; c++) {
            if (getCasella(0, c) == getCasella(1, c) && getCasella(1, c) == getCasella(2, c)) {
                if (getCasella(0, c) != -1 && getCasella(1, c) != -1 && getCasella(2, c) != -1) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean comprovaGuanyadorDiagonals() {
        // Diagonal derecha todas la fichas iguales
        if (getCasella(0, 0) == getCasella(1, 1) && getCasella(1, 1) == getCasella(2, 2)) {
            if (getCasella(0, 0) != -1 && getCasella(1, 1) != -1 && getCasella(2, 2) != -1) {
                return true;
            }
        }

        // Diagonal izquierda todas las fichas iguales
        if (getCasella(0, 2) == getCasella(1, 1) && getCasella(1, 1) == getCasella(2, 0)) {
            if (getCasella(0, 2) != -1 && getCasella(1, 1) != -1 && getCasella(2, 0) != -1) {
                return true;
            }
        }

        return false;
    }

    public void setCasella(int fila, int columna, int torn) {
        caselles[fila][columna] = torn;
    }

    public int getCasella(int fila, int columna) {
        return caselles[fila][columna];
    }

    public void mostrarTaulell() { // recorrer toda la array de casillas (tablero) y mostrar según el núm en esa casilla
        for (int f = 0; f < caselles.length; f++) {
            for (int c = 0; c < caselles.length; c++) {
                switch (caselles[f][c]) {
                    case -1:
                        System.out.print(" * ");
                        break;
                    case 0:
                        System.out.print(" O ");
                        break;
                    case 1:
                        System.out.print(" X ");
                        break;
                    default:
                        break;
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    public void moure(Moviment mov) {
        // introducir ficha en FILA y COLUMNA introducidas por el Jugador
        this.caselles[mov.getRow()][mov.getColumn()] = mov.getFitxa();
    }

    public boolean validarMoviment(Moviment mov) { //valida si las coordenadas introducidas, la casilla está vacía y si se encuentra dentro del tablero creado
        int fila = mov.getRow();
        int columna = mov.getColumn();
        if (fila >= 0 && fila < 3) { // si la fila se encuentra dentro del tablero
            if (columna >= 0 && columna < 3) { // si la columna se encuentra dentro del tablero
                return validarCasellaBuida(fila, columna);
            }
        }
        return false;
    }

    public boolean validarCasellaBuida(int fila, int columna) { // valida si las coordenadas introducidas, la casilla esta vacía
        if (getCasella(fila, columna) == -1) {
            return true;
        } else {
            return false;
        }
    }

}
