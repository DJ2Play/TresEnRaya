package TresEnRaya;

public class Moviment {

    private int row;
    private int column;
    private int fitxa;
    private Jugador jugador;

    public Moviment(Jugador j, int fila, int columna) {
        this.jugador = j;
        this.row = fila;
        this.column = columna;
    }

    public int getColumn() {
        return this.column;
    }

    public Jugador getJugador() {
        return this.jugador;
    }

    public int getFitxa() {
        return this.fitxa;
    }

    public int getRow() {
        return this.row;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public void setFitxa(int f){
        this.fitxa = f;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public void setRow(int row) {
        this.row = row;
    }
}
