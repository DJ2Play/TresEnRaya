package TresEnRaya;

public class IA0 extends Jugador {

    private Taulell taulell;

    public IA0() {
        super();
    }

    @Override
    public Moviment move() {
        Moviment mov = null;
        for (int f = 0; f < 3; f++) {
            for (int c = 0; c < 3; c++) {
                if (taulell.getCasella(f, c) == -1) {
                    mov = new Moviment(this, f, c);
                    mov.setFitxa(1);

                }
            }
        }
        return mov;
    }

    public void setTaulell(Taulell t) {
        this.taulell = t;
    }

}
