package TresEnRaya;

public class Ranking {

    private int partidesJugades;
    private int partidesGuanyades;
    private int partidesEmpatades;

    public Ranking() { //constructor del ranking
        this.partidesEmpatades = 0; //los seteamos a 0 como inicial
        this.partidesGuanyades = 0;
        this.partidesJugades = 0;
    }

    public void mostrarRanking() { //mostrar el menu del ranking
        System.out.println();
        System.out.println("Ranking");
        System.out.println("Partides jugades " + this.partidesJugades);
        System.out.println("Partides guanyades pel jugador " + this.partidesGuanyades);
        System.out.println("Partides guanyades per l'IA " + partidesGuanyadesIA());
        System.out.println("Partides empatades " + this.partidesEmpatades);
        System.out.println();
    }
    public void partidesJugades(){
        this.partidesJugades++;
    }

    public void partidesGuanyades(Jugador j1) {
        if (!(j1 instanceof IA0)) { //si Jugador no es IA
            partidesGuanyades++;
        }
        partidesJugades++;
    }

    public void partidesEmpatades() { //añadir una partida jugada y una empatada
        partidesEmpatades++;
        partidesJugades++;
    }
    public int partidesGuanyadesIA(){
        int guanyadesIA =this.partidesJugades - this.partidesGuanyades - this.partidesEmpatades;
        return guanyadesIA;
    }
}
