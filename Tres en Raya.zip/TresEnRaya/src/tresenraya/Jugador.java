package TresEnRaya;

import java.util.Scanner;

public class Jugador {

    private Partida partida;
    private Sessió sessió;

    public Jugador() {
    }

    public Moviment move() {
        Moviment moviment;
        Scanner scan = new Scanner(System.in);
        System.out.print("Tria fila: ");
        int fila = scan.nextInt();
        System.out.print("Tria columna: ");
        int columna = scan.nextInt();
        moviment = new Moviment(this, fila, columna);
        return moviment;
    }

    public Partida getPartida() {
        return partida;
    }

    public Sessió getSessió() {
        return sessió;
    }

    public void setPartida(Partida partida) {
        this.partida = partida;
    }

    public void setSessió(Sessió sessió) {
        this.sessió = sessió;
    }

}
