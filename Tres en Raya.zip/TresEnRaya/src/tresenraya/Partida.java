package TresEnRaya;

public class Partida {

    private int jugadaActual;
    private Taulell taulell;
    private Sessió sessió;
    private Jugador[] jugadors;
    private Ranking ranking;

    public Partida(Jugador j1, Jugador j2, Ranking r) {
        this.jugadors = new Jugador[2];
        this.jugadors[0] = j1;
        this.jugadors[1] = j2;
        this.taulell = new Taulell();
        this.ranking = r;
        if (j2 instanceof IA0) {
            ((IA0) j2).setTaulell(this.taulell);
        }
    }

    public void jugar(Jugador j1, IA0 ia) {
        int torn = this.sessió.sorteigTorn();
        int guanyador = -1; // jugador blancas == 0, jugador negras == 1, nadie == -1
        Moviment mov;
        this.taulell.mostrarTaulell();
        jugadaActual = torn;
        mov = this.jugadors[torn].move();
        while (this.taulell.validarMoviment(mov) && !taulell.comprovarGuanyador() && !taulell.comprovarEmpat()) {
            mov.setFitxa(torn);
            this.taulell.moure(mov);
            this.taulell.mostrarTaulell();
            this.jugadaActual++;
            torn = (jugadaActual) % 2;
            mov = this.jugadors[torn].move();
        }

        if (!this.taulell.validarMoviment(mov)) {
            System.out.println("Aquest moviment no és vàlid");
            System.out.println("El jugador ha perdut");
            guanyador = (torn++) % 2;
            this.ranking.partidesGuanyadesIA();
            this.sessió.mostrarMenu();
        }
        if (taulell.comprovarGuanyador()) {
            guanyador = torn;
            if (guanyador == -1) {
                System.out.print("No hi ha guanyador");
                this.sessió.mostrarMenu();
                this.ranking.partidesJugades();
            }
            System.out.println("El guanyador es " + guanyador);
            this.ranking.partidesGuanyades(j1);
            this.ranking.partidesJugades();
            this.sessió.mostrarMenu();
        }
        if (taulell.comprovarEmpat()) {
            System.out.println("La partida ha acabat en empat");
            this.ranking.partidesJugades();
            this.ranking.partidesEmpatades();
            this.sessió.mostrarMenu();
        }
    }

    public void mover(Moviment movi, int torn) {
        if (taulell.validarMoviment(movi)) {
            if (torn == 0) {
                taulell.setCasella(movi.getRow(), movi.getColumn(), torn);
            }
        }
    }

    public void setJugadaActual(int jugadaActual) {
        this.jugadaActual = jugadaActual;
    }

    public int getJugadaActual() {
        return jugadaActual;
    }

    public void setTaulell(Taulell taulell) {
        this.taulell = taulell;
    }

    public void setSessió(Sessió sessió) {
        this.sessió = sessió;
    }

}
