package TresEnRaya;

import java.util.Scanner;

public class Sessió {

    private Jugador[] jugadors;
    private Ranking ranking;

    public Sessió() {
        this.jugadors = new Jugador[2];
        this.jugadors[0] = new Jugador();
        this.jugadors[1] = new Jugador();
        this.ranking = new Ranking();
    }

    public void iniciSessio() {
        Jugador j1 = crearJugador();
        mostrarMenu();
        Ranking r = new Ranking();
        int opció = 0;
        while (opció != 1 || opció != 2 || opció != 3) {
            Scanner scan = new Scanner(System.in);
            System.out.println("Introdueix una opció: ");
            opció = scan.nextInt();
            switch (opció) {
                case 1:
                    IA0 ia = new IA0();
                    Partida p = crearPartida(j1, ia, r);
                    iniciarPartida(p,j1,ia);
                    break;
                case 2:
                    mostrarRanking();
                    break;
                case 3:
                    break;
                default:
                    System.out.println("ERROR 404: OPTION NOT FOUND");
                    break;
            }
        }
    }

    public static void iniciar() {
        Sessió s1 = new Sessió();
        s1.iniciSessio();
    }

    public void mostrarRanking() { // mostrar Ranking
        this.ranking.mostrarRanking();
        this.mostrarMenu();
    }

    public int sorteigTorn() { //sortear el turno (0 == jugador1 / 1 == jugador2)
        double torn; //numero entre 0 y 1
        torn = Math.random();
        if (torn < 0.5) {
            System.out.println("Comença el jugador O");
            return 0;
        }
        System.out.println("Comença el jugador X");
        return 1;
    }

    public Jugador crearJugador() {
        Jugador j1 = new Jugador();
        j1.setSessió(this);
        return j1;
    }

    /*public IA0 crearIA() {
        IA0 ia = new IA0();
        return ia;
    }*/

    public void mostrarMenu() { //mostrar menu
        System.out.println();
        System.out.println("-------MENU----------");
        System.out.println("        1. Jugar           ");
        System.out.println("        2. Ranking      ");
        System.out.println("        3. Sortir           ");
        System.out.println("-------------------------");
    }

    public Partida crearPartida(Jugador jugador, IA0 IA, Ranking r) {
        Partida p = new Partida(jugador, IA, r);
        p.setSessió(this);
        return p;
    }

    public void iniciarPartida(Partida p, Jugador j1, IA0 ia) {
        p.jugar(j1, ia);
    }

    public void setJugadores(Jugador[] jugadores) {
        this.jugadors = jugadores;
    }

    public void setRanking(Ranking ranking) {
        this.ranking = ranking;
    }

    public Jugador[] getJugadores() {
        return jugadors;
    }

    public Ranking getRanking() {
        return this.ranking;
    }

    public static void main(String[] args) {
        iniciar();

    }
}
